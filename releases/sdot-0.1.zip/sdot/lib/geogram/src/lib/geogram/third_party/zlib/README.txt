zlib: A Massively Spiffy Yet Delicately Unobtrusive Compression Library
website: http://zlib.net/


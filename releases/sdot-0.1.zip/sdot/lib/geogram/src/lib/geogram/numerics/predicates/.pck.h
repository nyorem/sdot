/* Automatically generated code, do not edit */
/* Generated from source file: */
